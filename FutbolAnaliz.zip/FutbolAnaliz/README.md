# Futbol Analiz (Android layihəsi)

Yalnız iki komandanın adını yazırsınız — tətbiq internetdən **real son oyun statistikasını** özü çəkib, riyazi model əsasında proqnoz verir:
- **1X2**: Ev sahibi qələbəsi / Heç-heçə / Qonaq qələbəsi
- **Qol/Qol (BTTS)**: hər iki komanda qol vuracaqmı
- **2.5 Üst/Alt**: ümumi qol sayı

## Necə işləyir (texniki)
1. Komanda adlarını **API-FOOTBALL**-da axtarır, ID-lərini tapır.
2. Hər komandanın **son 5 oyununu** (nəticə, vurulan/buraxılan qol) çəkir.
3. İki komandanın **son 5 qarşılıqlı görüşünü (H2H)** çəkir.
4. Bu məlumatlardan gözlənilən qol sayını (ev sahibliyi üstünlüyü daxil) hesablayıb, **Poisson ehtimal modeli** ilə hər nəticənin faizini çıxarır.

## ⚠️ Dürüst məhdudiyyət
Komandanın **heyəti, zədəli/cəzalı oyunçular, məşqçi dəyişikliyi** kimi məlumatlar pulsuz API-larda mövcud deyil (yalnız çox bahalı planlarda olur və bütün liqaları əhatə etmir). Ona görə analiz **nəticə + qol statistikası + qarşılıqlı görüş tarixçəsinə** əsaslanır — bu, real və faydalı, amma "tam heyət analizi" deyil. Nəticə heç vaxt uduş zəmanəti demək deyil.

## API açarını necə almaq olar? (PULSUZ)
1. https://dashboard.api-football.com/register ünvanında qeydiyyatdan keçin.
2. Dashboard-da "My Access" bölməsindən **API Key**-inizi kopyalayın (Free plan: gündə 100 sorğu).
3. Tətbiqi açıb bu açarı "API-FOOTBALL açarı" sahəsinə yapışdırın — bir dəfə yadda saxlanılır.

## APK-ya necə çevirmək olar?
1. [Android Studio](https://developer.android.com/studio) yükləyib quraşdırın.
2. "Open" seçib bu `FutbolAnaliz` qovluğunu açın, Gradle sync gözləyin (internet lazımdır).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Hazır APK: `app/build/outputs/apk/debug/app-debug.apk` — telefonunuza köçürüb quraşdırın (naməlum mənbələrə icazə tələb oluna bilər).

## Layihə strukturu
```
FutbolAnaliz/
  app/src/main/java/az/futbolanaliz/app/
    FootballApi.kt        -> API-FOOTBALL ilə şəbəkə əlaqəsi
    PredictionEngine.kt    -> Poisson qol modeli, 1X2 / BTTS / Over-Under
    MainActivity.kt        -> UI məntiqi
  app/src/main/res/        -> ekran dizaynı, rənglər, mətnlər
```

## Diqqət
Mərc oyunlarında pul itirmək riski həmişə var. Bu tətbiq statistik köməkçi alətdir, maliyyə məsləhəti deyil — büdcənizi qoruyun.
