package az.futbolanaliz.app

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class FootballApiException(message: String) : Exception(message)

object FootballApi {

    private const val BASE_URL = "https://v3.football.api-sports.io"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    data class TeamForm(
        val played: Int,
        val wins: Int,
        val draws: Int,
        val losses: Int,
        val goalsScored: Int,
        val goalsConceded: Int,
        val recentFormString: String
    )

    data class H2HStats(
        val matches: Int,
        val avgGoalsForHomeTeam: Double,
        val avgGoalsForAwayTeam: Double
    )

    private fun get(path: String, apiKey: String): JSONObject {
        val request = Request.Builder()
            .url(BASE_URL + path)
            .addHeader("x-apisports-key", apiKey)
            .build()

        client.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string() ?: throw FootballApiException("Boş cavab")
            if (!response.isSuccessful) {
                throw FootballApiException("API xətası (kod ${response.code}). API açarınızı yoxlayın.")
            }
            val json = JSONObject(bodyStr)
            val errors = json.opt("errors")
            if (errors is JSONObject && errors.length() > 0) {
                throw FootballApiException("API xətası: $errors")
            }
            return json
        }
    }

    /** Komanda adına görə axtarır, ilk uyğun nəticəni qaytarır: (id, tam ad) */
    fun findTeamId(name: String, apiKey: String): Pair<Int, String>? {
        val encoded = URLEncoder.encode(name, "UTF-8")
        val json = get("/teams?search=$encoded", apiKey)
        val arr = json.getJSONArray("response")
        if (arr.length() == 0) return null
        val team = arr.getJSONObject(0).getJSONObject("team")
        return Pair(team.getInt("id"), team.getString("name"))
    }

    /** Son N oyundan forma, qol statistikası çıxarır */
    fun getRecentForm(teamId: Int, apiKey: String, last: Int = 5): TeamForm {
        val json = get("/fixtures?team=$teamId&last=$last", apiKey)
        val arr = json.getJSONArray("response")
        var wins = 0; var draws = 0; var losses = 0
        var scored = 0; var conceded = 0
        val formChars = StringBuilder()

        for (i in 0 until arr.length()) {
            val fixture = arr.getJSONObject(i)
            val teams = fixture.getJSONObject("teams")
            val goals = fixture.getJSONObject("goals")
            val isHome = teams.getJSONObject("home").getInt("id") == teamId
            val goalsFor = if (isHome) goals.optInt("home", 0) else goals.optInt("away", 0)
            val goalsAgainst = if (isHome) goals.optInt("away", 0) else goals.optInt("home", 0)
            scored += goalsFor
            conceded += goalsAgainst
            when {
                goalsFor > goalsAgainst -> { wins++; formChars.append("W") }
                goalsFor < goalsAgainst -> { losses++; formChars.append("L") }
                else -> { draws++; formChars.append("D") }
            }
        }
        return TeamForm(arr.length(), wins, draws, losses, scored, conceded, formChars.toString())
    }

    /** homeId perspektivindən qarşılıqlı görüşlərin orta qol göstəriciləri */
    fun getHeadToHead(homeId: Int, awayId: Int, apiKey: String, last: Int = 5): H2HStats {
        val json = get("/fixtures/headtohead?h2h=$homeId-$awayId&last=$last", apiKey)
        val arr = json.getJSONArray("response")
        if (arr.length() == 0) return H2HStats(0, 0.0, 0.0)

        var goalsHomeTeamTotal = 0
        var goalsAwayTeamTotal = 0
        for (i in 0 until arr.length()) {
            val fixture = arr.getJSONObject(i)
            val teams = fixture.getJSONObject("teams")
            val goals = fixture.getJSONObject("goals")
            val fixtureHomeId = teams.getJSONObject("home").getInt("id")
            val gHome = goals.optInt("home", 0)
            val gAway = goals.optInt("away", 0)
            if (fixtureHomeId == homeId) {
                goalsHomeTeamTotal += gHome
                goalsAwayTeamTotal += gAway
            } else {
                goalsHomeTeamTotal += gAway
                goalsAwayTeamTotal += gHome
            }
        }
        val n = arr.length()
        return H2HStats(n, goalsHomeTeamTotal.toDouble() / n, goalsAwayTeamTotal.toDouble() / n)
    }
}
