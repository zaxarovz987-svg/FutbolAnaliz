package az.futbolanaliz.app

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import az.futbolanaliz.app.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("futbol_analiz_prefs", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.etApiKey.setText(prefs.getString("api_key", "a072f6c58956056c4f0cce76d5560e0e"))
        binding.btnAnalyze.setOnClickListener { runAnalysis() }
    }

    private fun runAnalysis() {
        val apiKey = binding.etApiKey.text.toString().trim()
        val homeName = binding.etHomeTeam.text.toString().trim()
        val awayName = binding.etAwayTeam.text.toString().trim()

        if (apiKey.isEmpty()) {
            Toast.makeText(this, "API açarını daxil edin (README-ə baxın)", Toast.LENGTH_LONG).show()
            return
        }
        if (homeName.isEmpty() || awayName.isEmpty()) {
            Toast.makeText(this, "Hər iki komandanın adını yazın", Toast.LENGTH_SHORT).show()
            return
        }

        prefs.edit().putString("api_key", apiKey).apply()

        binding.progress.visibility = View.VISIBLE
        binding.resultCard.visibility = View.GONE
        binding.btnAnalyze.isEnabled = false

        lifecycleScope.launch {
            try {
                val prediction = withContext(Dispatchers.IO) {
                    val home = FootballApi.findTeamId(homeName, apiKey)
                        ?: throw FootballApiException("'$homeName' komandası tapılmadı")
                    val away = FootballApi.findTeamId(awayName, apiKey)
                        ?: throw FootballApiException("'$awayName' komandası tapılmadı")

                    val homeForm = FootballApi.getRecentForm(home.first, apiKey)
                    val awayForm = FootballApi.getRecentForm(away.first, apiKey)
                    val h2h = FootballApi.getHeadToHead(home.first, away.first, apiKey)

                    PredictionEngine.predict(home.second, away.second, homeForm, awayForm, h2h)
                }
                showResult(prediction)
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, e.message ?: "Xəta baş verdi", Toast.LENGTH_LONG).show()
            } finally {
                binding.progress.visibility = View.GONE
                binding.btnAnalyze.isEnabled = true
            }
        }
    }

    private fun showResult(p: MatchPrediction) {
        binding.resultCard.visibility = View.VISIBLE

        binding.tvResultTeams.text = "${p.homeTeam}  vs  ${p.awayTeam}"
        binding.tvResultOutcome.text = "Proqnoz: ${p.recommendedOutcome}"
        binding.tvResultProbs.text = String.format(
            Locale.US,
            "Ev sahibi: %.1f%%    Heç-heçə: %.1f%%    Qonaq: %.1f%%",
            p.homeWinProb, p.drawProb, p.awayWinProb
        )
        binding.tvResultBtts.text =
            "${p.bttsRecommendation}   (ehtimal: ${String.format(Locale.US, "%.1f", p.bttsYesProb)}%)"
        binding.tvResultOver.text =
            "${p.overRecommendation}   (ehtimal: ${String.format(Locale.US, "%.1f", p.over25Prob)}%)"

        val h2hLine = if (p.h2h.matches > 0)
            "Son ${p.h2h.matches} qarşılıqlı görüşdə orta hesab: ${String.format(Locale.US, "%.1f", p.h2h.avgGoalsForHomeTeam)} - ${String.format(Locale.US, "%.1f", p.h2h.avgGoalsForAwayTeam)}"
        else
            "Qarşılıqlı görüş tapılmadı"

        binding.tvResultForm.text =
            "${p.homeTeam} son ${p.homeForm.played} oyun: ${p.homeForm.recentFormString}  (${p.homeForm.wins}Q ${p.homeForm.draws}B ${p.homeForm.losses}M, ${p.homeForm.goalsScored}:${p.homeForm.goalsConceded} qol)\n" +
            "${p.awayTeam} son ${p.awayForm.played} oyun: ${p.awayForm.recentFormString}  (${p.awayForm.wins}Q ${p.awayForm.draws}B ${p.awayForm.losses}M, ${p.awayForm.goalsScored}:${p.awayForm.goalsConceded} qol)\n\n" +
            h2hLine
    }
}
