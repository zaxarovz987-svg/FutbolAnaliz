package az.futbolanaliz.app

import kotlin.math.exp
import kotlin.math.pow

data class MatchPrediction(
    val homeTeam: String,
    val awayTeam: String,
    val homeWinProb: Double,
    val drawProb: Double,
    val awayWinProb: Double,
    val bttsYesProb: Double,
    val over25Prob: Double,
    val homeForm: FootballApi.TeamForm,
    val awayForm: FootballApi.TeamForm,
    val h2h: FootballApi.H2HStats
) {
    val recommendedOutcome: String
        get() {
            val best = maxOf(homeWinProb, drawProb, awayWinProb)
            return when (best) {
                homeWinProb -> "$homeTeam qazanır"
                awayWinProb -> "$awayTeam qazanır"
                else -> "Heç-heçə"
            }
        }
    val bttsRecommendation: String get() = if (bttsYesProb >= 50) "Qol/Qol (Bəli)" else "Qol/Yox (Xeyr)"
    val overRecommendation: String get() = if (over25Prob >= 50) "2.5 Üst" else "2.5 Alt"
}

/**
 * Sadələşdirilmiş Poisson qol modeli:
 *  - Hər komandanın son N oyundakı hücum/müdafiə ortalamasından gözlənilən qol sayı çıxarılır
 *  - Qarşılıqlı görüşlər (H2H) 30% çəki ilə qarışdırılır
 *  - Ev sahibliyi üstünlüyü tətbiq olunur
 *  - Poisson paylanması ilə 1X2, Qol/Qol və 2.5 Üst/Alt ehtimalları hesablanır
 * Bu, tarixi statistikaya əsaslanan RİYAZİ TƏXMİNDİR, nəticəni zəmanət etmir.
 */
object PredictionEngine {

    private const val HOME_ADVANTAGE = 1.1
    private const val H2H_WEIGHT = 0.3

    private fun factorial(n: Int): Double {
        var f = 1.0
        for (i in 2..n) f *= i
        return f
    }

    private fun poisson(lambda: Double, k: Int): Double {
        if (lambda <= 0.0) return if (k == 0) 1.0 else 0.0
        return exp(-lambda) * lambda.pow(k) / factorial(k)
    }

    fun predict(
        homeTeam: String,
        awayTeam: String,
        homeForm: FootballApi.TeamForm,
        awayForm: FootballApi.TeamForm,
        h2h: FootballApi.H2HStats
    ): MatchPrediction {
        val homeAvgScored = if (homeForm.played > 0) homeForm.goalsScored.toDouble() / homeForm.played else 1.2
        val homeAvgConceded = if (homeForm.played > 0) homeForm.goalsConceded.toDouble() / homeForm.played else 1.2
        val awayAvgScored = if (awayForm.played > 0) awayForm.goalsScored.toDouble() / awayForm.played else 1.0
        val awayAvgConceded = if (awayForm.played > 0) awayForm.goalsConceded.toDouble() / awayForm.played else 1.0

        val formExpHome = ((homeAvgScored + awayAvgConceded) / 2) * HOME_ADVANTAGE
        val formExpAway = (awayAvgScored + homeAvgConceded) / 2

        val expHome: Double
        val expAway: Double
        if (h2h.matches > 0) {
            expHome = formExpHome * (1 - H2H_WEIGHT) + h2h.avgGoalsForHomeTeam * H2H_WEIGHT
            expAway = formExpAway * (1 - H2H_WEIGHT) + h2h.avgGoalsForAwayTeam * H2H_WEIGHT
        } else {
            expHome = formExpHome
            expAway = formExpAway
        }

        var pHome = 0.0; var pDraw = 0.0; var pAway = 0.0
        var pBttsYes = 0.0; var pOver25 = 0.0
        val maxGoals = 6

        for (h in 0..maxGoals) {
            for (a in 0..maxGoals) {
                val p = poisson(expHome, h) * poisson(expAway, a)
                when {
                    h > a -> pHome += p
                    h == a -> pDraw += p
                    else -> pAway += p
                }
                if (h >= 1 && a >= 1) pBttsYes += p
                if (h + a >= 3) pOver25 += p
            }
        }

        val total = pHome + pDraw + pAway
        return MatchPrediction(
            homeTeam = homeTeam,
            awayTeam = awayTeam,
            homeWinProb = pHome / total * 100,
            drawProb = pDraw / total * 100,
            awayWinProb = pAway / total * 100,
            bttsYesProb = pBttsYes * 100,
            over25Prob = pOver25 * 100,
            homeForm = homeForm,
            awayForm = awayForm,
            h2h = h2h
        )
    }
}
